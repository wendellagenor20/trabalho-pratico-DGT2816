package com.doma.wearos.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import java.util.Locale

class DomaAudioController(
    private val context: Context,
    private val onAudioStateChanged: (speakerAvailable: Boolean, bluetoothConnected: Boolean, statusLog: String) -> Unit
) : TextToSpeech.OnInitListener {

    private val audioManager: AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val audioHelper = AudioHelper(context)
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var deviceCallback: AudioDeviceCallback? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "BR"))
            isTtsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED

            if (isTtsReady) {
                notifyState("Sistema de voz Doma pronto.")
            } else {
                notifyState("Idioma pt-BR não suportado no TTS.")
            }
        } else {
            notifyState("Falha ao inicializar mecanismo de voz.")
        }
    }

    fun registerDeviceCallback() {
        notifyState("Monitorando saídas de áudio...")

        val callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                super.onAudioDevicesAdded(addedDevices)
                if (audioHelper.isBluetoothHeadsetConnected()) {
                    val msg = "Fone Bluetooth conectado. Modo privado ativado."
                    notifyState(msg)
                    speak(msg)
                }
            }

            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                super.onAudioDevicesRemoved(removedDevices)
                if (!audioHelper.isBluetoothHeadsetConnected()) {
                    val msg = "Fone Bluetooth desconectado."
                    notifyState(msg)
                    if (audioHelper.isSpeakerAvailable()) {
                        speak(msg)
                    }
                }
            }
        }

        deviceCallback = callback
        audioManager.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
    }

    fun unregisterDeviceCallback() {
        deviceCallback?.let {
            audioManager.unregisterAudioDeviceCallback(it)
        }
        deviceCallback = null
    }

    fun openBluetoothSettings() {
        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra("EXTRA_CONNECTION_ONLY", true)
            putExtra("EXTRA_CLOSE_ON_CONNECT", true)
            putExtra("android.bluetooth.devicepicker.extra.FILTER_TYPE", 1)
        }
        context.startActivity(intent)
    }

    fun speak(
        text: String,
        requireBluetooth: Boolean = false,
        isEmergency: Boolean = false
    ) {
        val hasBluetooth = audioHelper.isBluetoothHeadsetConnected()
        val hasSpeaker = audioHelper.isSpeakerAvailable()

        if (requireBluetooth && !hasBluetooth) {
            notifyState("Conecte um fone Bluetooth para ouvir mensagens privadas.")
            openBluetoothSettings()
            return
        }

        if (!hasBluetooth && !hasSpeaker) {
            notifyState("Nenhuma saída de áudio disponível neste dispositivo.")
            return
        }

        if (isEmergency) {
            playAlertTone()
        }

        if (isTtsReady) {
            val queueMode = if (isEmergency) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            tts?.speak(text, queueMode, null, "doma_${System.currentTimeMillis()}")
            notifyState("Reproduzindo: "$text"")
        } else {
            notifyState("TTS indisponível: $text")
        }
    }

    fun playAlertTone() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            toneGen.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 600)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        unregisterDeviceCallback()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun notifyState(log: String) {
        onAudioStateChanged(
            audioHelper.isSpeakerAvailable(),
            audioHelper.isBluetoothHeadsetConnected(),
            log
        )
    }
}

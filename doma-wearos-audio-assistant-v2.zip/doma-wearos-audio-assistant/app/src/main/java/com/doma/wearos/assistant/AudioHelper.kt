package com.doma.wearos.assistant

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager

class AudioHelper(private val context: Context) {

    private val audioManager: AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun hasAudioOutputFeature(): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_OUTPUT)
    }

    fun audioOutputAvailable(type: Int): Boolean {
        if (!hasAudioOutputFeature()) {
            return false
        }

        return audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .any { it.type == type }
    }

    fun isSpeakerAvailable(): Boolean {
        return audioOutputAvailable(AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)
    }

    fun isBluetoothHeadsetConnected(): Boolean {
        return audioOutputAvailable(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)
    }
}

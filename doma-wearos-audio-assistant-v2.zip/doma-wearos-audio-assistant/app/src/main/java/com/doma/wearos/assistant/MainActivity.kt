package com.doma.wearos.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.TimeText
import androidx.wear.compose.material.Vignette
import androidx.wear.compose.material.VignettePosition
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                DomaWearApp()
            }
        }
    }
}

@Composable
fun DomaWearApp() {
    val context = LocalContext.current
    val listState = rememberScalingLazyListState()

    var hasSpeaker by remember { mutableStateOf(false) }
    var hasBluetooth by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("Inicializando áudio...") }

    val audioController = remember {
        DomaAudioController(context) { speaker, bluetooth, log ->
            hasSpeaker = speaker
            hasBluetooth = bluetooth
            statusMessage = log
        }
    }

    DisposableEffect(Unit) {
        audioController.registerDeviceCallback()
        onDispose {
            audioController.release()
        }
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenCommand = matches?.firstOrNull()?.lowercase(Locale("pt", "BR")) ?: ""

            when {
                spokenCommand.contains("mensagem") || spokenCommand.contains("notificação") -> {
                    audioController.speak(
                        "Você tem uma nova mensagem da equipe Doma: Reunião de alinhamento às 14 horas na sala 2."
                    )
                }
                spokenCommand.contains("treino") || spokenCommand.contains("treinamento") -> {
                    audioController.speak(
                        "Módulo de treinamento: Mantenha postura ergonômica e faça pausas de 5 minutos a cada hora."
                    )
                }
                spokenCommand.contains("alerta") || spokenCommand.contains("emergência") -> {
                    audioController.speak(
                        "Alerta de segurança Doma: Evacuação preventiva no setor B. Siga a sinalização sonora.",
                        isEmergency = true
                    )
                }
                else -> {
                    audioController.speak("Comando recebido: $spokenCommand. Diga ler mensagens, treinamento ou alerta.")
                }
            }
        }
    }

    Scaffold(
        timeText = { TimeText() },
        vignette = { Vignette(vignettePosition = VignettePosition.TopAndBottom) }
    ) {
        ScalingLazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .padding(horizontal = 10.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                Text(
                    text = "Doma Acessibilidade",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFF8AB4F8),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Text(
                    text = "Alto-falante: ${if (hasSpeaker) "Ativo" else "Indisponível"}\n" +
                           "Fone BT: ${if (hasBluetooth) "Conectado" else "Desconectado"}",
                    fontSize = 11.sp,
                    color = Color.LightGray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Chip(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        audioController.speak(
                            "Notificação interna Doma: Seu relatório de atividades foi aprovado pelo supervisor."
                        )
                    },
                    label = { Text("Ler Mensagens", fontSize = 12.sp) },
                    secondaryLabel = { Text("Leitura em voz alta", fontSize = 10.sp) },
                    colors = ChipDefaults.primaryChipColors()
                )
            }

            item {
                Chip(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        audioController.speak(
                            "Mensagem confidencial: Código de acesso atualizado para o turno da tarde.",
                            requireBluetooth = true
                        )
                    },
                    label = { Text("Mensagem Privada", fontSize = 12.sp) },
                    secondaryLabel = { Text("Requer fone Bluetooth", fontSize = 10.sp) },
                    colors = ChipDefaults.secondaryChipColors()
                )
            }

            item {
                Chip(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        audioController.speak(
                            "Instrução de treinamento: Verifique o equipamento de proteção antes de iniciar a operação."
                        )
                    },
                    label = { Text("Treinamento", fontSize = 12.sp) },
                    secondaryLabel = { Text("Dicas e feedback por áudio", fontSize = 10.sp) },
                    colors = ChipDefaults.secondaryChipColors()
                )
            }

            item {
                Chip(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        audioController.speak(
                            "Alerta crítico de segurança! Tempestade severa detectada na região. Permaneça em área coberta.",
                            isEmergency = true
                        )
                    },
                    label = { Text("Alerta de Segurança", fontSize = 12.sp) },
                    secondaryLabel = { Text("Emergência / Tempestade", fontSize = 10.sp) },
                    colors = ChipDefaults.chipColors(backgroundColor = Color(0xFFB3261E))
                )
            }

            item {
                Chip(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(
                                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                            )
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga um comando...")
                        }
                        try {
                            voiceLauncher.launch(intent)
                        } catch (e: Exception) {
                            audioController.speak("Reconhecimento de voz não disponível no emulador.")
                        }
                    },
                    label = { Text("Comando de Voz", fontSize = 12.sp) },
                    secondaryLabel = { Text("Falar com o assistente", fontSize = 10.sp) },
                    colors = ChipDefaults.secondaryChipColors()
                )
            }

            item {
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { audioController.openBluetoothSettings() },
                    colors = ButtonDefaults.secondaryButtonColors()
                ) {
                    Text("Configurar Bluetooth", fontSize = 11.sp)
                }
            }

            item {
                Text(
                    text = statusMessage,
                    fontSize = 10.sp,
                    color = Color(0xFFA8C7FA),
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 12.dp)
                )
            }
        }
    }
}

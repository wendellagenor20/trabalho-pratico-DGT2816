# Doma Wear OS - Assistente de Áudio e Acessibilidade

Projeto desenvolvido para o **Trabalho Prático: Lidando com sensores em dispositivos móveis**, focado no desenvolvimento de uma aplicação **Wear OS** para a empresa **Doma**.

## Objetivo e Contextualização
A empresa **Doma** busca melhorar a eficiência e a comunicação interna, promovendo a inclusão de funcionários com necessidades especiais (especialmente deficiência visual). Este aplicativo wearable utiliza recursos de áudio em tempo real para:
- **Leitura de mensagens e notificações** em voz alta via *Text-to-Speech (TTS)*.
- **Comandos de voz** (*SpeechRecognizer*) para interação rápida sem depender exclusivamente da tela.
- **Treinamento e educação**, fornecendo instruções auditivas e feedbacks.
- **Alertas de segurança críticos** utilizando o alto-falante integrado (`TYPE_BUILTIN_SPEAKER`) e/ou fones Bluetooth (`TYPE_BLUETOOTH_A2DP`).

## Funcionalidades Implementadas
1. **Verificação de Saídas de Áudio (`AudioHelper.kt`)**: checa `PackageManager.FEATURE_AUDIO_OUTPUT`, `AudioDeviceInfo.TYPE_BUILTIN_SPEAKER` e `AudioDeviceInfo.TYPE_BLUETOOTH_A2DP`.
2. **Detecção Dinâmica em Tempo Real (`AudioDeviceCallback`)**: monitora conexão (`onAudioDevicesAdded`) e desconexão (`onAudioDevicesRemoved`) de fones Bluetooth.
3. **Atalho Inteligente para Configurações Bluetooth**: abre `Settings.ACTION_BLUETOOTH_SETTINGS` com filtros de dispositivos de áudio.
4. **Reprodução de Voz e Alertas Sonoros (`DomaAudioController.kt`)**: síntese de voz em `pt-BR` com `TextToSpeech` e sinais sonoros com `ToneGenerator`.
5. **Reconhecimento de Comandos de Voz (`MainActivity.kt`)**: integração com `RecognizerIntent.ACTION_RECOGNIZE_SPEECH`.

## Como Executar
1. Abra o projeto no **Android Studio**.
2. Configure um **Emulador Wear OS** (API 30+) ou conecte um relógio físico via ADB.
3. Sincronize o **Gradle** e clique em **Run**.
